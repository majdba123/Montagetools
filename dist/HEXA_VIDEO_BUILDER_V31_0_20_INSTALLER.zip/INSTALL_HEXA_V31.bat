@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

set "LOGDIR=%LOCALAPPDATA%\HEXA\VideoBuilderV31\install_logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1
set "BOOTLOG=%LOGDIR%\BOOTSTRAP_LATEST.log"
set "INSTALLMARKER=%LOGDIR%\CURRENT_INSTALLER_LOG.txt"
if exist "%INSTALLMARKER%" del /q "%INSTALLMARKER%" >nul 2>&1
>"%BOOTLOG%" echo HEXA V31.0.20 BOOTSTRAP
>>"%BOOTLOG%" echo PACKAGE=%~dp0
>>"%BOOTLOG%" echo STARTED=%DATE% %TIME%

set "HEXA_V31_INSTALL_LOG_MARKER=%INSTALLMARKER%"

echo ============================================================
echo HEXA Video Builder V31.0.20 - Production Hardened
echo ============================================================
echo [BOOT] Runtime recovery hardened: Python candidates are executed before selection.
echo [BOOT] Broken legacy virtual environments are skipped, never trusted by file existence alone.
echo [BOOT] V27/V26/V25/V24/V23/V20/V12 caches, models, and dependency roots are reused only after exact physical probes.
echo [BOOT] This window will remain open on PASS or FAIL.
echo [BOOT] Bootstrap log: %BOOTLOG%

set "RC=0"
set "PYEXE="
set "PYSOURCE="

rem -----------------------------------------------------------------
rem Probe known HEXA runtimes. A python.exe file is NOT sufficient:
rem Windows venv redirectors can remain after pyvenv.cfg is deleted.
rem -----------------------------------------------------------------
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV31\runtime\.venv\Scripts\python.exe" "HEXA_V31"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV27\runtime\.venv\Scripts\python.exe" "HEXA_V27"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV26\runtime\.venv\Scripts\python.exe" "HEXA_V26"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV25\runtime\.venv\Scripts\python.exe" "HEXA_V25"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV24\runtime\.venv\Scripts\python.exe" "HEXA_V24"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV23\runtime\.venv\Scripts\python.exe" "HEXA_V23"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV20\runtime\.venv\Scripts\python.exe" "HEXA_V20"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV17\runtime\.venv\Scripts\python.exe" "HEXA_V17"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV16\runtime\.venv\Scripts\python.exe" "HEXA_V16"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV12\runtime\.venv\Scripts\python.exe" "HEXA_V12"
call :TRY_PY "%LOCALAPPDATA%\HEXA\VideoBuilderV8\runtime\.venv\Scripts\python.exe" "HEXA_V8"

rem Probe every python.exe visible in PATH, not just the first result.
if not defined PYEXE (
  for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYEXE call :TRY_PY "%%~fP" "PATH"
)

rem The Python launcher can reveal a base interpreter even when it is not in PATH.
if not defined PYEXE (
  for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PYEXE call :TRY_PY "%%P" "PY_LAUNCHER"
)

rem Common per-user / machine install locations.
if not defined PYEXE (
  for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python*") do if not defined PYEXE call :TRY_PY "%%~fD\python.exe" "LOCALAPPDATA_PROGRAMS"
)
if not defined PYEXE (
  for /d %%D in ("%ProgramFiles%\Python*") do if not defined PYEXE call :TRY_PY "%%~fD\python.exe" "PROGRAMFILES"
)
if not defined PYEXE if exist "%ProgramFiles(x86)%" (
  for /d %%D in ("%ProgramFiles(x86)%\Python*") do if not defined PYEXE call :TRY_PY "%%~fD\python.exe" "PROGRAMFILES_X86"
)

if not defined PYEXE (
  echo [FATAL] No executable Python runtime passed the bootstrap probe.
  echo [FATAL] Existing python.exe files with missing pyvenv.cfg are treated as broken and skipped.
  >>"%BOOTLOG%" echo FATAL=NO_EXECUTABLE_PYTHON_RUNTIME
  set "RC=106"
  goto FINISH
)

echo [BOOT] Python: %PYEXE%
echo [BOOT] Python source: %PYSOURCE%
>>"%BOOTLOG%" echo PYTHON=%PYEXE%
>>"%BOOTLOG%" echo PYTHON_SOURCE=%PYSOURCE%

"%PYEXE%" "%~dp0tools\install_v31.py"
set "RC=%ERRORLEVEL%"
>>"%BOOTLOG%" echo PYTHON_EXIT_CODE=%RC%

if not "%RC%"=="0" (
  echo.
  echo ============================================================
  echo HEXA V31 INSTALLATION: FAIL ^(exit code %RC%^)
  echo ============================================================
  goto FINISH
)

echo.
echo ============================================================
echo HEXA V31 INSTALLATION: PASS
echo ============================================================
echo OPEN PREMIERE PRO 2022 ^> Window ^> Extensions ^> HEXA Video Builder V31

goto FINISH

:TRY_PY
if defined PYEXE exit /b 0
set "CAND=%~1"
set "CSOURCE=%~2"
if not defined CAND exit /b 0
if not exist "%CAND%" exit /b 0
set "PROBEFILE=%TEMP%\hexa_v31_pyprobe_%RANDOM%_%RANDOM%.txt"
"%CAND%" -c "import sys;print(sys.executable);print(sys.version.split()[0])" >"%PROBEFILE%" 2>&1
set "PRC=!ERRORLEVEL!"
if not "!PRC!"=="0" (
  echo [BOOT] SKIP unusable Python [!CSOURCE!]: !CAND!
  >>"%BOOTLOG%" echo SKIP_PYTHON_SOURCE=!CSOURCE!
  >>"%BOOTLOG%" echo SKIP_PYTHON_PATH=!CAND!
  >>"%BOOTLOG%" echo SKIP_PYTHON_EXIT=!PRC!
  findstr /i /c:"No pyvenv.cfg file" "!PROBEFILE!" >nul 2>&1
  if not errorlevel 1 (
    echo [BOOT]   Reason: broken virtual environment metadata ^(pyvenv.cfg missing^).
    >>"%BOOTLOG%" echo SKIP_PYTHON_REASON=MISSING_PYVENV_CFG
  )
  type "!PROBEFILE!" >>"%BOOTLOG%"
  del /q "!PROBEFILE!" >nul 2>&1
  exit /b 0
)
set "PYEXE=!CAND!"
set "PYSOURCE=!CSOURCE!"
for /f "usebackq delims=" %%Q in ("!PROBEFILE!") do if not defined PYPROBE_EXE set "PYPROBE_EXE=%%Q"
>>"%BOOTLOG%" echo ACCEPT_PYTHON_SOURCE=!PYSOURCE!
>>"%BOOTLOG%" echo ACCEPT_PYTHON_PATH=!PYEXE!
>>"%BOOTLOG%" echo ACCEPT_PYTHON_REPORTED_EXE=!PYPROBE_EXE!
del /q "!PROBEFILE!" >nul 2>&1
exit /b 0

:FINISH
set "LASTLOG="
if exist "%INSTALLMARKER%" set /p LASTLOG=<"%INSTALLMARKER%"
echo.
echo Diagnostics:
echo   Bootstrap: %BOOTLOG%
if defined LASTLOG (
  echo   Installer:  %LASTLOG%
) else (
  echo   Installer:  not started in this run
)
echo.
if not "%RC%"=="0" echo Send the Bootstrap log plus Installer log if one was created.
echo This window will stay open so the result cannot disappear.
echo Press any key only after you have read/copied the final result.
pause >nul
exit /b %RC%
