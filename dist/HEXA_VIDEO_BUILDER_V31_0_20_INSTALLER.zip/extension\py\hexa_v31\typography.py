from __future__ import annotations
import os, pathlib, re
from PIL import Image, ImageDraw, ImageFont, features

_ARABIC_RE=re.compile(r'[\u0600-\u06FF]')
_LATIN_RE=re.compile(r'[A-Za-z]')
_DIGIT_RE=re.compile(r'[0-9٠-٩]')
_TRIM=' \t\r\n،,.;:؛!?؟-–—()[]{}"\''
TYPE_PRIORITY={'PRICE':9.5,'NUMBER':9.0,'STATUS':8.7,'LABEL':7.3,'CONCEPT':6.9,'CARD':4.2,'UI':4.2,'DEVICE':3.2,'OBJECT':2.7,'GROUP':2.7,'ICON':2.2}
GENERIC_SEMANTIC_ACTIONS=('LIMIT','FAIL','REJECT','STATUS','ERROR','BLOCK','WARNING','RESULT','SOLUTION','PROBLEM','COMPARE','CAUSE','EFFECT','CHANGE','INCREASE','DECREASE','RISK','PRICE','COST','NUMBER','PERCENT','TOTAL','AVAILABLE','RESERVED','DEFINE','NAME','KEY','FOCUS','CONCLUSION','SUCCESS','APPROVE','COMPLETE')
# Language glue, not topic knowledge. This is used only to avoid rendering fragments such as "لكن" or "في" as graphics.
WEAK_WORDS={'و','أو','او','بس','لكن','لأن','لان','إذا','اذا','حتى','مع','من','في','على','عن','هذا','هذه','هذي','ذلك','تلك','اللي','إنه','انه','ثم','بعد','قبل','عند','كان','كانت','يكون','تكون','هو','هي','هم','ما','مو','مش','لا','لم','لن','قد','كل','أي','اي','أكثر','اقل','أقل'}


def _scene_timing(alignment):
    return {str(x.get('scene_id')):x for x in (alignment.get('scene_timings') or [])}


def _trigger_time(trigger,alignment,scene_row):
    st=float(scene_row.get('start',0)); en=float(scene_row.get('end',st+1))
    if trigger:
        a=int(trigger.get('global_char_start',-1)); b=int(trigger.get('global_char_end',-1)); rows=alignment.get('word_timings') or []
        if rows and a>=0 and b>=a:
            wr=[r for r in rows if int(r.get('char_end',-1))>a and int(r.get('char_start',10**9))<b]
            if wr:
                return max(st,float(wr[0].get('start',st))-0.02),min(en,float(wr[-1].get('end',st+0.3))+0.04)
    return st+min(0.22,max(0.05,(en-st)*0.20)),min(en-0.03,st+min(1.7,max(0.72,(en-st)*0.72)))


def _clean(s):
    return ' '.join(str(s or '').split()).strip(_TRIM)

def validate_viewer_text(value, script_language=None):
    """Strict firewall: rendering is for authored/canonical copy, never machine labels."""
    s=_clean(value)
    if not s or len(s)>64 or '_' in s or re.search(r'(^|\s)[A-Z][A-Z0-9_]{2,}($|\s)',s):return False
    if re.search(r'\b(?:semantic|visual|state|role|slug|asset|unit|scene|card|function|meaning)\b',s,re.I):return False
    if str(script_language or '').lower() in ('ar','arabic') and not _ARABIC_RE.search(s):return False
    return _is_displayable(s)

def measure_title_layout(text, canvas_w, canvas_h, w_norm, h_norm):
    """Measure shaped text with the actual installed font; no character-count cropping."""
    path=find_arabic_font(True)
    if not path:return {'fits':False,'rtl_capable':False,'reason':'NO_GLYPH_CAPABLE_FONT'}
    w,h=int(canvas_w*w_norm),int(canvas_h*h_norm);rtl=bool(_ARABIC_RE.search(str(text)));raqm=bool(features.check('raqm'));draw_value=str(text) if (not rtl or raqm) else _fallback_shape(str(text));fallback_ok=(not rtl or raqm or draw_value!=str(text))
    for size in range(int(60*canvas_h/1080),int(31*canvas_h/1080)-1,-2):
        font=ImageFont.truetype(path,max(18,size));draw=ImageDraw.Draw(Image.new('RGBA',(w,h)))
        kw={'font':font};
        if rtl and raqm:kw.update(direction='rtl',language='ar')
        try: box=draw.textbbox((0,0),draw_value,**kw)
        except Exception:continue
        if box[2]-box[0]<=w-38 and box[3]-box[1]<=h-26:return {'fits':True,'font_size':size,'line_count':1,'rtl_capable':fallback_ok,'measured_width':box[2]-box[0]}
    return {'fits':False,'rtl_capable':fallback_ok,'reason':'MEASURED_TEXT_DOES_NOT_FIT'}


def _word_clean(w):
    return str(w or '').strip(_TRIM)


def _is_displayable(s):
    s=_clean(s)
    if not s or len(s)<2 or len(s)>36:return False
    words=s.split()
    if len(words)>5:return False
    if not (_ARABIC_RE.search(s) or _LATIN_RE.search(s) or _DIGIT_RE.search(s)):return False
    return True


def _strip_weak_prefix(s):
    words=_clean(s).split()
    while len(words)>=2 and _word_clean(words[0]).lower() in WEAK_WORDS:
        words=words[1:]
    return _clean(' '.join(words))


def _phrase_quality(s):
    s=_clean(s)
    if not _is_displayable(s):return -999.0
    words=s.split(); clean=[_word_clean(w) for w in words]
    content=[w for w in clean if w and w.lower() not in WEAK_WORDS]
    numeric=bool(_DIGIT_RE.search(s))
    if not numeric and not content:return -999.0
    score=0.0
    score+=4.0 if numeric else 0.0
    score+=2.2 if len(words) in (2,3) else 1.0 if len(words)==1 else 0.7
    score+=1.2 if 5<=len(s)<=26 else 0.2
    score+=0.8*min(3,len(content))
    if clean and clean[0].lower() in WEAK_WORDS:score-=2.0
    if clean and clean[-1].lower() in WEAK_WORDS:score-=2.0
    return score


def _exact_subphrases(raw):
    """Return compact contiguous literal phrases without inventing copy.

    V22 could only use a trigger when the whole trigger was <=5 words, which collapsed real
    production coverage to 8.16%. V31 searches literal contiguous n-grams and clause fragments,
    scoring them for readability. The selected text always remains an exact substring of narration.
    """
    raw=' '.join(str(raw or '').split())
    out=[]
    if not raw:return out
    whole=_strip_weak_prefix(raw)
    if _is_displayable(whole):out.append((whole,_phrase_quality(whole)+1.0))
    # Clause candidates first.
    for clause in re.split(r'[،,;؛:!?؟]+',raw):
        c=_strip_weak_prefix(clause)
        if _is_displayable(c):out.append((c,_phrase_quality(c)+0.8))
    tokens=raw.split()
    # Sliding 1..4 word literal windows. This is content-agnostic and preserves exact wording.
    for size in (2,3,1,4):
        for i in range(0,max(0,len(tokens)-size+1)):
            cand=_clean(' '.join(tokens[i:i+size]))
            cand2=_strip_weak_prefix(cand)
            if not cand2 or cand2 not in raw:continue
            q=_phrase_quality(cand2)
            if q>-100:out.append((cand2,q))
    # Deduplicate while retaining highest quality.
    best={}
    for text,score in out:
        if text not in best or score>best[text]:best[text]=score
    return sorted(best.items(),key=lambda x:(-x[1],len(x[0].split()),len(x[0])))


def _best_exact_subphrase(raw):
    rows=_exact_subphrases(raw)
    return rows[0][0] if rows else ''


def _style_for(typ,nf,phrase,scene):
    rel=str(scene.get('relation_to_previous') or '').upper()
    if typ in ('PRICE','NUMBER') or _DIGIT_RE.search(phrase):return 'NUMERIC_HERO'
    if typ=='STATUS' or any(k in nf for k in ('FAIL','REJECT','STATUS','ERROR','BLOCK','WARNING','SUCCESS','APPROVE','COMPLETE')):return 'STATUS_BADGE'
    if rel in ('COMPARE','COMPARISON') or any(k in nf for k in ('COMPARE','LIMIT','CONTRAST','VERSUS')):return 'CONTRAST_LABEL'
    if typ in ('LABEL','UI','DEVICE','CARD'):return 'MICRO_LABEL'
    return 'KEY_TERM'


def _candidate(scene,unit):
    typ=str(unit.get('type') or '').upper(); role=str(unit.get('role') or '').upper(); tr=unit.get('focus_trigger') or unit.get('appear_trigger')
    raw=(tr or {}).get('phrase') or ''
    rows=_exact_subphrases(raw)
    if not rows:return None
    phrase,pq=rows[0]
    score=float(TYPE_PRIORITY.get(typ,1.0))+(3.2 if role=='PRIMARY' else 0.8 if role=='SUPPORTING' else 0)+pq*0.55
    if _DIGIT_RE.search(phrase):score+=3.2
    nf=str(unit.get('narrative_function') or '').upper(); score+=min(3.2,sum(0.8 for k in GENERIC_SEMANTIC_ACTIONS if k in nf))
    if str(unit.get('semantic_intent') or '').upper() in ('INTRODUCE','EMPHASIZE','COMPARE','RESOLVE','REVEAL','FOCUS'):score+=1.1
    return {'scene_id':scene['scene_id'],'text':phrase,'unit_id':unit.get('unit_id'),'unit_type':typ,'role':role,'trigger':tr,'score':round(score,3),'style':_style_for(typ,nf,phrase,scene),'source':'UNIT_TRIGGER_LITERAL_SUBPHRASE'}


def _fallback(scene):
    raw=((scene.get('script_span') or {}).get('text') or '')
    rows=_exact_subphrases(raw)
    if not rows:return None
    phrase,pq=rows[0]
    numeric=bool(_DIGIT_RE.search(phrase))
    # Scene-span fallback must be genuinely compact, not a quota filler.
    if not numeric and pq<4.0:return None
    score=4.8+pq*0.50+(2.8 if numeric else 0.0)
    style='NUMERIC_HERO' if numeric else 'KEY_TERM'
    return {'scene_id':scene['scene_id'],'text':phrase,'unit_id':None,'unit_type':'SCRIPT_SPAN','role':'PRIMARY','trigger':None,'score':round(score,3),'style':style,'source':'SCENE_SCRIPT_LITERAL_SUBPHRASE'}


def _overlap(a,b):
    ax,ay,aw,ah=a; bx,by,bw,bh=b; ix=max(0,min(ax+aw,bx+bw)-max(ax,bx)); iy=max(0,min(ay+ah,by+bh)-max(ay,by)); return ix*iy/max(1e-9,aw*ah)


def _choose_slot(vscene,text,style):
    slots=[('TOP_RIGHT',0.59,0.065,0.33,0.15),('TOP_LEFT',0.08,0.065,0.33,0.15),('MID_RIGHT',0.66,0.34,0.26,0.18),('MID_LEFT',0.08,0.34,0.26,0.18),('BOTTOM_RIGHT',0.59,0.78,0.33,0.15),('BOTTOM_LEFT',0.08,0.78,0.33,0.15),('TOP_CENTER',0.27,0.05,0.46,0.15),('BOTTOM_CENTER',0.27,0.80,0.46,0.14)]
    boxes=[]
    for u in (vscene.get('units') or []):
        b=u.get('bbox_norm') or []
        if len(b)==4:
            x,y,w,h=map(float,b); pad=0.028; boxes.append((max(0,x-pad),max(0,y-pad),min(1,x+w+pad)-max(0,x-pad),min(1,y+h+pad)-max(0,y-pad)))
    best=None
    for idx,(name,x,y,w,h) in enumerate(slots):
        ov=sum(_overlap((x,y,w,h),b) for b in boxes); center_pen=0.08 if 'CENTER' in name else 0; score=ov+center_pen+idx*0.002
        if best is None or score<best[0]:best=(score,name,x,y,w,h,ov)
    if not best or best[6]>0.30:return None
    _,name,x,y,w,h,ov=best; return {'slot':name,'x_norm':x,'y_norm':y,'w_norm':w,'h_norm':h,'visual_overlap_score':round(ov,4)}


def build_text_plan(package,alignment,vision_results,motion_plan,logger=None):
    scenes=package.plan.get('scenes') or []; vmap={str(v.get('scene_id')):v for v in vision_results}; tmap=_scene_timing(alignment); candidates=[]
    for order,scene in enumerate(scenes,1):
        sr=tmap.get(str(scene.get('scene_id')))
        if not sr:continue
        dur=max(0.0,float(sr.get('end',0))-float(sr.get('start',0)))
        # Typography on micro-beats is usually unreadable and competes with the visual transition.
        if dur<0.85:continue
        best=None
        for unit in (scene.get('units') or []):
            c=_candidate(scene,unit)
            if c and (best is None or c['score']>best['score']):best=c
        fb=_fallback(scene)
        if best is None or (fb and fb['score']>best['score']+1.2):best=fb or best
        if best:
            best['scene_order']=order; best['duration_seconds']=dur; best['placement']=_choose_slot(vmap.get(scene['scene_id'],{}),best['text'],best['style'])
            if best['placement']:candidates.append(best)

    # Adaptive opportunity-driven density, not a fixed per-project quota.
    strong=[c for c in candidates if c['score']>=10.0 or c['style'] in ('NUMERIC_HERO','STATUS_BADGE')]
    eligible=max(1,sum(1 for s in scenes if (lambda r: r and float(r.get('end',0))-float(r.get('start',0))>=0.85)(tmap.get(str(s.get('scene_id'))))))
    desired=int(round(eligible*0.24)); upper=int(round(eligible*0.34)); target=min(len(candidates),max(min(len(strong),upper),desired)); target=min(target,max(1,upper)) if candidates else 0
    selected=[]; orders=set(); texts=set()
    for c in sorted(candidates,key=lambda x:(-x['score'],x['scene_order'])):
        norm=re.sub(r'\s+',' ',c['text']).strip()
        if norm in texts:continue
        o=int(c['scene_order'])
        if any(abs(o-u)<=1 for u in orders) and c['style'] not in ('NUMERIC_HERO','STATUS_BADGE'):
            continue
        selected.append(c);orders.add(o);texts.add(norm)
        if len(selected)>=target:break
    if len(selected)<target:
        for c in sorted(candidates,key=lambda x:(-x['score'],x['scene_order'])):
            norm=re.sub(r'\s+',' ',c['text']).strip()
            if c in selected or norm in texts:continue
            selected.append(c);orders.add(int(c['scene_order']));texts.add(norm)
            if len(selected)>=target:break

    out=[]
    for i,c in enumerate(sorted(selected,key=lambda x:x['scene_order']),1):
        sr=tmap.get(c['scene_id'])
        if not sr:continue
        ts,te=_trigger_time(c.get('trigger'),alignment,sr); ss=float(sr['start']); se=float(sr['end']); dur=max(0.05,se-ss)
        start=max(ss+0.03,ts-0.03); hold=1.30 if c['style'] in ('KEY_TERM','MICRO_LABEL') else 1.55; end=min(se-0.03,max(te+0.45,start+min(hold,max(0.52,dur*0.62))))
        if end-start<0.45:continue
        pl=c['placement']; style=c['style']
        slide_dx = 0.032 if 'LEFT' in pl['slot'] else (-0.032 if 'RIGHT' in pl['slot'] else 0.0)
        slide_dy = 0.014 if 'TOP' in pl['slot'] else (-0.014 if 'BOTTOM' in pl['slot'] else 0.0)
        out.append({'text_id':f'TEXT_{i:03d}','scene_id':c['scene_id'],'scene_order':c['scene_order'],'unit_id':c.get('unit_id'),'text':c['text'],'style':style,'start_seconds':round(start,6),'end_seconds':round(end,6),'fade_in_seconds':0.24,'fade_out_seconds':0.18,'pop_scale_from':1.0,'pop_scale_peak':1.0,'pop_scale_end':1.0,'slide_dx_norm':slide_dx,'slide_dy_norm':slide_dy,'slide_duration_seconds':0.42,'motion_preset':'TEXT_POSITION_SOFT__12F_MIN','x_norm':pl['x_norm'],'y_norm':pl['y_norm'],'w_norm':pl['w_norm'],'h_norm':pl['h_norm'],'slot':pl['slot'],'font_policy':'WINDOWS_ARABIC_UI_BOLD_FALLBACK','font_candidates':['Segoe UI Semibold','Segoe UI Bold','Tahoma Bold','Arial Bold'],'semantic_source':c.get('source'),'score':c['score'],'visual_overlap_score':pl['visual_overlap_score'],'budget_cost':0.24 if style in ('KEY_TERM','MICRO_LABEL') else 0.30})
    result={'schema':'HEXA_SELECTIVE_TYPOGRAPHY_PLAN_V31','version':'3.0','policy':'OPPORTUNITY_DRIVEN_SEMANTIC_NOT_SUBTITLE','scene_count':len(scenes),'eligible_scene_count':eligible,'opportunity_count':len(candidates),'target_count':target,'text_event_count':len(out),'coverage_scene_percent':round(100.0*len(out)/max(1,len(scenes)),2),'eligible_coverage_percent':round(100.0*len(out)/max(1,eligible),2),'events':out,'hard_rules':{'not_every_scene':True,'max_one_text_event_per_scene':True,'exact_narration_substring_required':True,'no_full_sentence_subtitles':True,'max_words':5,'max_chars':36,'negative_space_placement_required':True,'arabic_shaping_required':True,'system_font_only_no_bundled_font_files':True,'adaptive_coverage':True,'topic_specific_keyword_dependency':False,'minimum_duration_seconds':0.85,'quota_filling_forbidden':True}}
    if logger:logger.log('PASS','SELECTIVE_TYPOGRAPHY_PLAN_BUILT',text_events=len(out),scene_count=len(scenes),eligible_scenes=eligible,opportunities=len(candidates),coverage_percent=result['coverage_scene_percent'],styles=sorted(set(e['style'] for e in out)))
    return result


def find_arabic_font(bold=True):
    windir=os.environ.get('WINDIR') or os.environ.get('SystemRoot') or r'C:\\Windows'; wd=pathlib.Path(windir)/'Fonts'; names=['seguisb.ttf','segoeuib.ttf','tahomabd.ttf','arialbd.ttf'] if bold else ['segoeui.ttf','tahoma.ttf','arial.ttf']
    for n in names:
        p=wd/n
        if p.is_file():return str(p)
    for p in (pathlib.Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),pathlib.Path('/usr/share/fonts/truetype/freefont/FreeSans.ttf')):
        if p.is_file():return str(p)
    return None


def _fallback_shape(text):
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(text))
    except Exception:return text


def render_text_rgba(event,canvas_w=1920,canvas_h=1080):
    w=max(250,int(round(float(event.get('w_norm',0.34))*canvas_w))); h=max(105,int(round(float(event.get('h_norm',0.15))*canvas_h))); style=str(event.get('style') or 'KEY_TERM'); font_path=find_arabic_font(True)
    if not font_path:raise RuntimeError('No suitable Arabic system font found.')
    base={'NUMERIC_HERO':80,'STATUS_BADGE':62,'CONTRAST_LABEL':58,'KEY_TERM':60,'MICRO_LABEL':52}.get(style,58)
    if len(str(event.get('text','')))>22:base-=7
    font=ImageFont.truetype(font_path,size=max(18,int(round(base*(canvas_h/1080.0)))))
    img=Image.new('RGBA',(w,h),(0,0,0,0)); d=ImageDraw.Draw(img); text=str(event.get('text') or ''); use_raqm=bool(features.check('raqm')); draw_text=text if use_raqm else _fallback_shape(text); kw={'font':font,'fill':(22,22,22,255)}; mk={'font':font}
    if use_raqm:kw.update(direction='rtl',language='ar');mk.update(direction='rtl',language='ar')
    try:box=d.textbbox((0,0),draw_text,**mk)
    except TypeError:
        kw.pop('direction',None);kw.pop('language',None);mk.pop('direction',None);mk.pop('language',None);box=d.textbbox((0,0),draw_text,**mk)
    tw=box[2]-box[0]; th=box[3]-box[1]; px=26; py=13; rx=max(8,(w-(tw+2*px))//2); ry=max(6,(h-(th+2*py))//2)
    if style=='STATUS_BADGE':d.rounded_rectangle((rx,ry,min(w-rx,rx+tw+2*px),min(h-ry,ry+th+2*py)),radius=20,fill=(255,255,255,242),outline=(120,35,35,115),width=3)
    elif style=='NUMERIC_HERO':d.rounded_rectangle((rx,ry,min(w-rx,rx+tw+2*px),min(h-ry,ry+th+2*py)),radius=18,fill=(255,255,255,238),outline=(30,30,30,60),width=2)
    elif style=='CONTRAST_LABEL':d.rounded_rectangle((rx,ry,min(w-rx,rx+tw+2*px),min(h-ry,ry+th+2*py)),radius=12,fill=(255,255,255,224),outline=(50,50,50,45),width=2)
    elif style=='MICRO_LABEL':d.rounded_rectangle((rx,ry,min(w-rx,rx+tw+2*px),min(h-ry,ry+th+2*py)),radius=10,fill=(255,255,255,215),outline=(50,50,50,35),width=1)
    x=(w-tw)/2.0; y=(h-th)/2.0-box[1]
    try:d.text((x,y),draw_text,**kw)
    except TypeError:kw.pop('direction',None);kw.pop('language',None);d.text((x,y),draw_text,**kw)
    if style=='KEY_TERM':
        yy=min(h-8,int(y+th+8));d.rounded_rectangle((max(14,int(x)),yy,min(w-14,int(x+tw)),yy+3),radius=2,fill=(30,30,30,150))
    elif style=='NUMERIC_HERO':
        d.rounded_rectangle((max(18,rx+8),min(h-7,ry+5),max(24,rx+38),min(h-3,ry+8)),radius=2,fill=(30,30,30,135))
    return img
